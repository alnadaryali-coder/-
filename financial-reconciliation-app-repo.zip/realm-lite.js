/**
 * realm-lite.js
 * ----------------------------------------------------------------------------
 * طبقة تخزين محلية خفيفة تعمل كبديل متوافق (Drop-in) لمكتبة Realm.
 * السبب: مكتبة realm تحتوي على وحدات أصلية (Native Modules) يجب تجميعها
 * لكل نظام تشغيل ونسخة Electron على حدة، وهذا يمنع بناء نسخة Windows جاهزة.
 * هذه الطبقة تحفظ البيانات في ملف JSON داخل مجلد بيانات المستخدم، وتوفر
 * نفس الواجهة المستخدمة في التطبيق: objects / filtered / write / create /
 * close / BSON.ObjectId.
 * ----------------------------------------------------------------------------
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/* ------------------------------ BSON.ObjectId ----------------------------- */
class ObjectId {
  constructor(id) {
    if (id instanceof ObjectId) id = id.id;
    this.id = id || crypto.randomBytes(12).toString('hex');
  }
  toString() { return this.id; }
  toJSON() { return this.id; }
  equals(other) { return String(other) === this.id; }
}

/* ------------------------------ Schema utils ----------------------------- */
function coerce(value, type) {
  if (value === undefined || value === null) {
    return type && type.endsWith('?') ? null : value;
  }
  const t = (type || '').replace('?', '');
  switch (t) {
    case 'double':
    case 'float':
    case 'int':
      return typeof value === 'number' ? value : (parseFloat(value) || 0);
    case 'string':
      return value instanceof ObjectId ? value.toString() : String(value);
    case 'objectId__':
    case 'objectId':
      return value instanceof ObjectId ? value.toString() : String(value);
    case 'bool':
      return Boolean(value);
    case 'list':
    case 'string[]':
      return Array.isArray(value) ? value.map((v) => String(v)) : [];
    default:
      return value;
  }
}

/* ----------------------------- Query evaluator ---------------------------- */
/* يدعم استعلامات من نوع:  prop == $0 AND price < 10 OR name CONTAINS "x"   */
function tokenize(query) {
  const tokens = [];
  const re = /\s*(\(|\)|==|!=|>=|<=|>|<|&&|\|\||,|"[^"]*"|'[^']*'|\$[A-Za-z0-9_]+|\bAND\b|\bOR\b|\bNOT\b|\bCONTAINS\b|\bBEGINSWITH\b|\bENDSWITH\b|\bLIKE\b|[A-Za-z_][A-Za-z0-9_.]*|-?\d+(?:\.\d+)?|true|false|null)/gi;
  let m;
  let lastIndex = 0;
  while ((m = re.exec(query)) !== null) {
    if (m.index !== lastIndex) break;
    tokens.push(m[0].trim());
    lastIndex = re.lastIndex;
  }
  return tokens;
}

function buildPredicate(query, args) {
  const tokens = tokenize(String(query));
  let pos = 0;

  const peek = () => tokens[pos];
  const next = () => tokens[pos++];

  function parseValue(tok) {
    if (tok === undefined) return { kind: 'const', value: undefined };
    if (/^\$[A-Za-z0-9_]+$/.test(tok)) {
      const idx = parseInt(tok.slice(1), 10);
      return { kind: 'const', value: args[idx] };
    }
    if (/^["']/.test(tok)) return { kind: 'const', value: tok.slice(1, -1) };
    if (tok === 'true') return { kind: 'const', value: true };
    if (tok === 'false') return { kind: 'const', value: false };
    if (tok === 'null') return { kind: 'const', value: null };
    if (/^-?\d/.test(tok)) return { kind: 'const', value: parseFloat(tok) };
    return { kind: 'field', name: tok };
  }

  // مقارنة واحدة: <operand> <op> <operand>
  function parseComparison() {
    const left = parseValue(next());
    const op = next();
    let right;
    if (['CONTAINS', 'BEGINSWITH', 'ENDSWITH', 'LIKE'].includes(op)) {
      right = parseValue(next());
    } else {
      right = parseValue(next());
    }
    return (obj) => {
      const lv = left.kind === 'field' ? obj[left.name] : left.value;
      const rv = right.kind === 'field' ? obj[right.name] : right.value;
      return compare(lv, op, rv);
    };
  }

  function compare(a, op, b) {
    // مقارنة رقمية إذا كان أحد الطرفين رقمًا
    const numA = typeof a === 'number' ? a : parseFloat(a);
    const numB = typeof b === 'number' ? b : parseFloat(b);
    const bothNumeric =
      a !== null && b !== null && a !== '' && b !== '' &&
      !isNaN(numA) && !isNaN(numB) &&
      (typeof a === 'number' || typeof b === 'number' ||
        (typeof a === 'string' && typeof b === 'string' && /^-?\d+(\.\d+)?$/.test(a) && /^-?\d+(\.\d+)?$/.test(b)));
    const sa = a === null || a === undefined ? '' : String(a);
    const sb = b === null || b === undefined ? '' : String(b);

    switch (op) {
      case '==': return bothNumeric ? numA === numB : sa === sb;
      case '!=': return bothNumeric ? numA !== numB : sa !== sb;
      case '>': return bothNumeric && numA > numB;
      case '<': return bothNumeric && numA < numB;
      case '>=': return bothNumeric && numA >= numB;
      case '<=': return bothNumeric && numA <= numB;
      case 'CONTAINS': return sa.toLowerCase().includes(sb.toLowerCase());
      case 'BEGINSWITH': return sa.toLowerCase().startsWith(sb.toLowerCase());
      case 'ENDSWITH': return sa.toLowerCase().endsWith(sb.toLowerCase());
      case 'LIKE': {
        const pattern = sb.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.');
        return new RegExp('^' + pattern + '$', 'i').test(sa);
      }
      default: return false;
    }
  }

  function parsePrimary() {
    if (peek() === '(') {
      next();
      const inner = parseOr();
      if (peek() === ')') next();
      return inner;
    }
    if (peek() === 'NOT') {
      next();
      const inner = parsePrimary();
      return (o) => !inner(o);
    }
    return parseComparison();
  }

  function parseAnd() {
    let left = parsePrimary();
    while (peek() === 'AND' || peek() === '&&') {
      next();
      const right = parsePrimary();
      const l = left;
      left = (o) => l(o) && right(o);
    }
    return left;
  }

  function parseOr() {
    let left = parseAnd();
    while (peek() === 'OR' || peek() === '||') {
      next();
      const right = parseAnd();
      const l = left;
      left = (o) => l(o) || right(o);
    }
    return left;
  }

  if (tokens.length === 0) return () => true;
  const predicate = parseOr();
  return predicate;
}

/* ------------------------------ Results class ----------------------------- */
class Results {
  constructor(realm, schemaName, rows) {
    this._realm = realm;
    this._name = schemaName;
    this._rows = rows || [];
    // السماح بالوصول بالفهرس الرقمي: results[0] كما في Realm
    return new Proxy(this, {
      get(target, prop, receiver) {
        if (typeof prop === 'string' && /^\d+$/.test(prop)) return target._rows[Number(prop)];
        return Reflect.get(target, prop, receiver);
      },
      has(target, prop) {
        if (typeof prop === 'string' && /^\d+$/.test(prop)) return Number(prop) < target._rows.length;
        return Reflect.has(target, prop);
      },
    });
  }
  get length() { return this._rows.length; }
  get isValid() { return true; }
  get type() { return this._name; }
  toJSON() { return this._rows.map((r) => Object.assign({}, r)); }
  map(fn, thisArg) { return this._rows.map((r, i) => fn.call(thisArg, r, i, this)); }
  forEach(fn, thisArg) { this._rows.forEach((r, i) => fn.call(thisArg, r, i, this)); }
  some(fn, thisArg) { return this._rows.some((r, i) => fn.call(thisArg, r, i, this)); }
  every(fn, thisArg) { return this._rows.every((r, i) => fn.call(thisArg, r, i, this)); }
  find(fn, thisArg) { return this._rows.find((r, i) => fn.call(thisArg, r, i, this)); }
  slice(start, end) { return new Results(this._realm, this._name, this._rows.slice(start, end)); }
  at(i) { return this._rows.at(i); }
  sorted(keyOrFn, reverse) {
    const arr = this._rows.slice();
    if (typeof keyOrFn === 'function') arr.sort(keyOrFn);
    else if (Array.isArray(keyOrFn)) {
      if (reverse) arr.reverse();
    } else {
      arr.sort((a, b) => (a[keyOrFn] > b[keyOrFn] ? 1 : a[keyOrFn] < b[keyOrFn] ? -1 : 0));
      if (reverse) arr.reverse();
    }
    return new Results(this._realm, this._name, arr);
  }
  filtered(query, ...args) {
    const predicate = buildPredicate(query, args);
    return new Results(this._realm, this._name, this._rows.filter((r) => predicate(r)));
  }
  indexOf(row) { return this._rows.indexOf(row); }
  [Symbol.iterator]() { return this._rows[Symbol.iterator](); }
}

/* --------------------------------- Realm --------------------------------- */
class RealmLite {
  constructor(config) {
    this.config = config || {};
    this.isClosed = false;
    this._schemas = {};
    for (const s of this.config.schema || []) this._schemas[s.name] = s;
    this._file = this.config.path || 'realm-lite.json';
    this._data = {};
    for (const name of Object.keys(this._schemas)) this._data[name] = [];
    this._load();
  }

  /* --- persistence --- */
  _load() {
    try {
      if (fs.existsSync(this._file)) {
        const raw = fs.readFileSync(this._file, 'utf8');
        if (raw && raw.trim()) {
          const parsed = JSON.parse(raw);
          for (const name of Object.keys(this._data)) {
            if (Array.isArray(parsed[name])) this._data[name] = parsed[name];
          }
        }
      }
    } catch (err) {
      console.error('[realm-lite] تعذر قراءة قاعدة البيانات، سيتم البدء بقاعدة جديدة:', err.message);
      try { fs.copyFileSync(this._file, this._file + '.corrupt-' + Date.now()); } catch (_) {}
    }
  }

  _save() {
    try {
      fs.mkdirSync(path.dirname(this._file), { recursive: true });
      const tmp = this._file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this._data), 'utf8');
      fs.renameSync(tmp, this._file);
    } catch (err) {
      console.error('[realm-lite] تعذر حفظ قاعدة البيانات:', err.message);
    }
  }

  _schema(name) {
    const schema = this._schemas[name];
    if (!schema) throw new Error(`Schema "${name}" not found`);
    return schema;
  }

  _coerceObject(name, obj) {
    const schema = this._schema(name);
    const out = {};
    const props = schema.properties || {};
    for (const key of Object.keys(props)) {
      if (obj[key] !== undefined) out[key] = coerce(obj[key], props[key]);
    }
    // قيم افتراضية للخصائص غير المعطاة (سلوك قريب من Realm)
    for (const key of Object.keys(props)) {
      if (out[key] !== undefined) continue;
      const t = String(props[key]);
      if (t.endsWith('?')) out[key] = null;
      else if (/(double|float|int)/.test(t)) out[key] = 0;
      else if (/string/.test(t)) out[key] = '';
      else if (/bool/.test(t)) out[key] = false;
      else if (/(\[\]|list)/.test(t)) out[key] = [];
    }
    for (const key of Object.keys(obj)) {
      if (out[key] === undefined) out[key] = coerce(obj[key], 'mixed');
    }
    return out;
  }

  /* --- public API --- */
  static open(config) {
    try {
      return Promise.resolve(new RealmLite(config));
    } catch (err) {
      return Promise.reject(err);
    }
  }

  static get BSON() {
    return { ObjectId };
  }

  objects(name) {
    if (this.isClosed) throw new Error('Cannot access objects on a closed Realm');
    return new Results(this, name, this._data[name] || (this._data[name] = []));
  }

  write(fn) {
    if (typeof fn !== 'function') return undefined;
    const result = fn();
    this._save();
    return result;
  }

  create(name, obj, updateMode) {
    const list = this._data[name] || (this._data[name] = []);
    const record = this._coerceObject(name, obj);
    const schema = this._schema(name);
    const pk = schema.primaryKey;

    if (pk && record[pk] != null) {
      const existingIndex = list.findIndex((r) => String(r[pk]) === String(record[pk]));
      if (existingIndex >= 0) {
        if (updateMode === true || updateMode === 'all') {
          list[existingIndex] = Object.assign({}, list[existingIndex], record);
          return list[existingIndex];
        }
        if (updateMode === 'modified') {
          for (const k of Object.keys(record)) {
            if (record[k] !== undefined) list[existingIndex][k] = record[k];
          }
          return list[existingIndex];
        }
        throw new Error(`Attempting to create an object of type '${name}' with an existing primary key value.`);
      }
    }
    list.push(record);
    return record;
  }

  delete(name, objOrPredicate) {
    const list = this._data[name] || [];
    if (typeof objOrPredicate === 'function') {
      this._data[name] = list.filter((r) => !objOrPredicate(r));
    } else if (objOrPredicate && objOrPredicate._id !== undefined) {
      const idx = list.findIndex((r) => r._id === String(objOrPredicate._id));
      if (idx >= 0) list.splice(idx, 1);
    }
  }

  deleteMany(name, ...args) {
    if (typeof args[0] === 'string') {
      const predicate = buildPredicate(args[0], args.slice(1));
      this._data[name] = (this._data[name] || []).filter((r) => !predicate(r));
    } else {
      this._data[name] = [];
    }
  }

  deleteAll() {
    for (const name of Object.keys(this._data)) this._data[name] = [];
    this._save();
  }

  objectForPrimaryKey(name, key) {
    const list = this._data[name] || [];
    return list.find((r) => String(r._id) === String(key));
  }

  close() {
    if (this.isClosed) return;
    this._save();
    this.isClosed = true;
  }
}

/* استخراج السجلات ككائنات JS عادية */
RealmLite.prototype.objectsForSchema = function (name) {
  return (this._data[name] || []).slice();
};

RealmLite.ObjectId = ObjectId;
module.exports = RealmLite;
