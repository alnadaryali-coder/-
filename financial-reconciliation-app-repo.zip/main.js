const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const Realm = require('./realm-lite');
const fs = require('fs');

let mainWindow;
let realm;

// 1. مخطط جدول الحسابات والجهات (Accounts / Entities Schema)
const AccountSchema = {
  name: 'Account',
  primaryKey: '_id',
  properties: {
    _id: 'objectId',
    name: 'string',
    type: 'string',          // cash, exchange, bank, client
    currency: 'string',      // SAR, YER, USD, AED
    initialBalance: 'double',
    accountNumber: 'string?',
    phone: 'string?',
    notes: 'string?'
  }
};

// 2. مخطط جدول بنود المصروفات والإيرادات (Categories Schema)
const CategorySchema = {
  name: 'Category',
  primaryKey: '_id',
  properties: {
    _id: 'objectId',
    name: 'string',
    type: 'string',          // expense, income, transfer, settlement
    keywords: 'string[]'     // كلمات التعرف التلقائي الذكي
  }
};

// 3. مخطط جدول الحركات المالية (Transactions Schema)
const TransactionSchema = {
  name: 'Transaction',
  primaryKey: '_id',
  properties: {
    _id: 'objectId',
    date: 'string',
    docType: 'string',
    docNum: 'string',
    account: 'string',
    accountId: 'string?',
    beneficiary: 'string',
    description: 'string',
    debit: 'double',
    credit: 'double',
    categoryId: 'string?',
    categoryName: 'string?'
  }
};

async function initRealm() {
  const dbPath = path.join(app.getPath('userData'), 'exchange_dark_reconcile.realm');
  realm = await Realm.open({
    path: dbPath,
    schema: [AccountSchema, CategorySchema, TransactionSchema],
    schemaVersion: 3
  });

  seedDefaultData();
}

function seedDefaultData() {
  if (realm.objects('Account').length === 0) {
    realm.write(() => {
      realm.create('Account', {
        _id: new Realm.BSON.ObjectId(),
        name: 'صندوق الفرع الرئيسي (كاش)',
        type: 'cash',
        currency: 'SAR',
        initialBalance: 50000.0,
        accountNumber: 'BOX-001',
        phone: '',
        notes: 'صندوق النقدية المباشرة'
      });
      realm.create('Account', {
        _id: new Realm.BSON.ObjectId(),
        name: 'شركة العمقي للصرافة',
        type: 'exchange',
        currency: 'SAR',
        initialBalance: 120000.0,
        accountNumber: 'AMQ-88219',
        phone: '+967 777123456',
        notes: 'حساب التسويات وتغطية الحوالات'
      });
      realm.create('Account', {
        _id: new Realm.BSON.ObjectId(),
        name: 'شركة البسيري للصرافة',
        type: 'exchange',
        currency: 'SAR',
        initialBalance: 85000.0,
        accountNumber: 'BSR-55120',
        phone: '+967 771987654',
        notes: 'حساب تغذية الفروع ومراكز الصرافة'
      });
      realm.create('Account', {
        _id: new Realm.BSON.ObjectId(),
        name: 'مصرف الراجحي',
        type: 'bank',
        currency: 'SAR',
        initialBalance: 340000.0,
        accountNumber: 'SA44800002146080100',
        phone: '',
        notes: 'الحساب التجاري الرئيسي للعمليات والمدفوعات الدولية'
      });
    });
  }

  if (realm.objects('Category').length === 0) {
    realm.write(() => {
      realm.create('Category', {
        _id: new Realm.BSON.ObjectId(),
        name: 'عمولات تحويل ورسوم سويفت',
        type: 'expense',
        keywords: ['عمولة', 'رسوم', 'سويفت', 'مقاصة', 'خدمة', 'commission', 'fee']
      });
      realm.create('Category', {
        _id: new Realm.BSON.ObjectId(),
        name: 'مصاريف إدارية وتشغيلية',
        type: 'expense',
        keywords: ['إيجار', 'كهرباء', 'مطبوعات', 'صيانة', 'نقل', 'تأمين', 'ضيافة']
      });
      realm.create('Category', {
        _id: new Realm.BSON.ObjectId(),
        name: 'أرباح وفروقات صرافة',
        type: 'income',
        keywords: ['فارق صرف', 'أرباح', 'تقييم', 'فروقات', 'شراء عملات']
      });
      realm.create('Category', {
        _id: new Realm.BSON.ObjectId(),
        name: 'حوالات تجارية ومشتريات',
        type: 'transfer',
        keywords: ['فاتورة', 'بضاعة', 'استيراد', 'توريد', 'سبائك', 'ذهب']
      });
    });
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 750,
    backgroundColor: '#020617',
    title: 'نظام المطابق المالي الذكي - كشوفات الصرافة (وائل حسن)',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile('index.html');
  mainWindow.setMenuBarVisibility(false);
}

app.whenReady().then(async () => {
  await initRealm();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (realm && !realm.isClosed) realm.close();
  if (process.platform !== 'darwin') app.quit();
});

// IPC Handlers
ipcMain.handle('accounts:get-all', async () => {
  const records = realm.objects('Account');
  return records.map(a => ({
    _id: a._id.toString(),
    name: a.name,
    type: a.type,
    currency: a.currency,
    initialBalance: a.initialBalance,
    accountNumber: a.accountNumber || '',
    phone: a.phone || '',
    notes: a.notes || ''
  }));
});

ipcMain.handle('categories:get-all', async () => {
  const records = realm.objects('Category');
  return records.map(c => ({
    _id: c._id.toString(),
    name: c.name,
    type: c.type,
    keywords: Array.from(c.keywords)
  }));
});

ipcMain.handle('db:get-all', async () => {
  const records = realm.objects('Transaction');
  return records.map(tx => ({
    _id: tx._id.toString(),
    date: tx.date,
    docType: tx.docType,
    docNum: tx.docNum,
    account: tx.account,
    accountId: tx.accountId || '',
    beneficiary: tx.beneficiary,
    description: tx.description,
    debit: tx.debit,
    credit: tx.credit,
    categoryId: tx.categoryId || '',
    categoryName: tx.categoryName || ''
  }));
});

ipcMain.handle('db:import-batch', async (event, rows) => {
  let insertedCount = 0;
  let skippedCount = 0;
  const categories = realm.objects('Category');

  realm.write(() => {
    for (const row of rows) {
      const existing = realm.objects('Transaction').filtered(
        'date == $0 AND docNum == $1 AND debit == $2 AND credit == $3',
        row.date,
        String(row.docNum),
        row.debit,
        row.credit
      );

      if (existing.length === 0) {
        let matchedCatId = row.categoryId || '';
        let matchedCatName = row.categoryName || '';

        if (!matchedCatId && row.description) {
          const descLower = row.description.toLowerCase();
          for (const cat of categories) {
            const hasMatch = cat.keywords.some(kw => descLower.includes(kw.toLowerCase()));
            if (hasMatch) {
              matchedCatId = cat._id.toString();
              matchedCatName = cat.name;
              break;
            }
          }
        }

        realm.create('Transaction', {
          _id: new Realm.BSON.ObjectId(),
          date: String(row.date || ''),
          docType: String(row.docType || 'قيد آلي'),
          docNum: String(row.docNum || ''),
          account: String(row.account || 'صندوق المركز'),
          accountId: row.accountId || '',
          beneficiary: String(row.beneficiary || 'غير محدد'),
          description: String(row.description || ''),
          debit: parseFloat(row.debit) || 0.0,
          credit: parseFloat(row.credit) || 0.0,
          categoryId: matchedCatId,
          categoryName: matchedCatName
        });
        insertedCount++;
      } else {
        skippedCount++;
      }
    }
  });

  return { insertedCount, skippedCount };
});

ipcMain.handle('dialog:open-excel-file', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    title: 'اختر كشف حساب إكسل للشركة أو البنك',
    filters: [{ name: 'Excel Files', extensions: ['xlsx', 'xls'] }],
    properties: ['openFile']
  });

  if (canceled || filePaths.length === 0) return null;
  return fs.readFileSync(filePaths[0]);
});
// إضافة حركة مالية مفردة (كانت مُعرّفة في preload.js بدون معالج)
ipcMain.handle('db:add-single', async (event, row) => {
  let created = null;

  realm.write(() => {
    let matchedCatId = row.categoryId || '';
    let matchedCatName = row.categoryName || '';

    if (!matchedCatId && row.description) {
      const descLower = String(row.description).toLowerCase();
      for (const cat of realm.objects('Category')) {
        if (cat.keywords.some(kw => descLower.includes(kw.toLowerCase()))) {
          matchedCatId = cat._id.toString();
          matchedCatName = cat.name;
          break;
        }
      }
    }

    created = realm.create('Transaction', {
      _id: new Realm.BSON.ObjectId(),
      date: String(row.date || ''),
      docType: String(row.docType || 'قيد آلي'),
      docNum: String(row.docNum || ''),
      account: String(row.account || 'صندوق المركز'),
      accountId: row.accountId || '',
      beneficiary: String(row.beneficiary || 'غير محدد'),
      description: String(row.description || ''),
      debit: parseFloat(row.debit) || 0.0,
      credit: parseFloat(row.credit) || 0.0,
      categoryId: matchedCatId,
      categoryName: matchedCatName
    });
  });

  return created ? created._id.toString() : null;
});

// حذف حركة مالية مفردة
ipcMain.handle('db:delete-single', async (event, id) => {
  const record = realm.objectForPrimaryKey('Transaction', id);
  if (!record) return false;

  realm.write(() => {
    realm.delete('Transaction', record);
  });

  return true;
});
