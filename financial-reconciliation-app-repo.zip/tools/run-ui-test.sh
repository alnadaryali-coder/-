#!/usr/bin/env bash
# تشغيل اختبار الواجهة الكامل مع أخذ الصور
# المتطلبات: xvfb (للتشغيل بدون شاشة) + node_modules مثبّتة (npm install)
set -u

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEST_DIR="/tmp/test-app"
SHOT_DIR="$APP_DIR/../test-shots"
RAW_OUT="/tmp/test-shots-raw"

echo "== تجهيز مجلد الاختبار =="
rm -rf "$TEST_DIR" "$RAW_OUT"
mkdir -p "$TEST_DIR" "$RAW_OUT" "$SHOT_DIR"

cp "$APP_DIR"/{index.html,style.css,renderer.js,preload.js,realm-lite.js} "$TEST_DIR"/
cp -r "$APP_DIR/vendor" "$TEST_DIR"/
cp "$APP_DIR/main.js" "$TEST_DIR/app-main.js"
cp "$APP_DIR/tools/ui-test-harness.js" "$TEST_DIR/harness.js"
printf '{ "name": "financial-reconciliation-app", "version": "2.5.0", "main": "harness.js" }\n' > "$TEST_DIR/package.json"

ELECTRON="$APP_DIR/node_modules/electron/dist/electron"
if [ ! -x "$ELECTRON" ]; then echo "!! electron غير مثبّت — نفّذ npm install داخل $APP_DIR"; exit 1; fi

echo "== حذف بيانات الاختبار السابقة =="
rm -rf "$HOME/.config/financial-reconciliation-app"

run_phase () {
  local phase="$1"
  echo "== تشغيل المرحلة: $phase =="
  PHASE="$phase" SHOT_DIR="$RAW_OUT" XLSX_FILE="$(dirname "$0")/test-data/كشف-العمقي-يناير.xlsx" \
    timeout 90 xvfb-run -a --server-args="-screen 0 1500x950x24" \
    "$ELECTRON" --no-sandbox "$TEST_DIR" 2>&1 |
    grep -E "SHOT|TEST_FAIL" || true
}

run_phase main
run_phase restart

cp "$RAW_OUT"/*.png "$SHOT_DIR"/ 2>/dev/null
cp "$RAW_OUT"/logs.json "$SHOT_DIR"/ 2>/dev/null
echo "== الصور في: $SHOT_DIR =="
ls -1 "$SHOT_DIR"
