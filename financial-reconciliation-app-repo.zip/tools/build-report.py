#!/usr/bin/env python3
"""
build-report.py — يبني تقرير الاختبار HTML من مخرجات الاختبار.

المدخلات:
  docs/logs.json           سجل العمليات (يُنتجه tools/ui-test-harness.js داخل test-shots/logs.json)
  docs/screenshots/*.png   لقطات الشاشة

المخرجات:
  docs/test-report.html    نسخة خفيفة تشير إلى الصور (مناسبة للمستودع)
  --embed                  نسخة مستقلة تضمّن الصور base64 (للعرض والمشاركة)

الاستخدام:
  python3 tools/build-report.py            # خفيفة
  python3 tools/build-report.py --embed    # مستقلة
"""
import base64
import datetime
import html
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, 'docs')
SHOTS = os.path.join(DOCS, 'screenshots')
EMBED = '--embed' in sys.argv
OUT = os.path.join(DOCS, 'test-report-embedded.html' if EMBED else 'test-report.html')

FINDINGS = [
    ("preload.js لا يمرّر بيانات الاستيراد",
     "الدالة كانت <code>importBatch: (rows) =&gt; ipcRenderer.invoke('db:import-batch')</code> — أي أن <code>rows</code> لا يُرسل إلى العملية الرئيسية، فكل استيراد يفشل بـ <code>TypeError: rows is not iterable</code>.",
     "تمرير الوسيط: <code>ipcRenderer.invoke('db:import-batch', rows)</code>."),
    ("زر «استيراد كشف Excel» غير موصول بأي كود",
     "لا يوجد في <code>renderer.js</code> أي مستمع نقر ولا استدعاء للاستيراد؛ الزر لم يكن يفعل شيئاً.",
     "قراءة الملف بـ XLSX، تحويل العناوين العربية، الاستيراد، ورسالة بالنتيجة."),
    ("قائمة الحركات كانت بيانات ثابتة",
     "<code>renderRecentMovements(txs)</code> كانت تتجاهل الوسيط وتعرض أسطراً مكتوبة يدوياً.",
     "عرض الحركات الحقيقية من قاعدة البيانات وتحديث البطاقات الأربع بالمجاميع."),
    ("البحث السريع غير مفعّل",
     "الحقل موجود في الواجهة بلا أي كود بحث.",
     "بحث فوري في رقم المستند والجهة والبيان والحساب والتصنيف."),
    ("معالجا IPC ناقصان",
     "<code>addTransaction</code> و<code>deleteTransaction</code> في preload بلا معالجات في main.",
     "إضافة <code>db:add-single</code> و<code>db:delete-single</code>."),
]


def main():
    logs = json.load(open(os.path.join(DOCS, 'logs.json'), encoding='utf-8'))
    steps = logs['logs'] if isinstance(logs, dict) else logs
    console = logs.get('consoleMsgs', []) if isinstance(logs, dict) else []
    passed = sum(1 for s in steps if s.get('verdict') == 'pass')

    blocks = []
    for i, s in enumerate(steps, 1):
        png = os.path.join(SHOTS, s['file'])
        if EMBED:
            src = 'data:image/png;base64,' + base64.b64encode(open(png, 'rb').read()).decode()
        else:
            src = 'screenshots/' + s['file']
        badge = ('<span class="badge pass">ناجح ✔</span>' if s.get('verdict') == 'pass'
                 else '<span class="badge fail">فشل ✘</span>')
        blocks.append(f"""
    <section class="step">
      <div class="step-head"><span class="num">{i}</span>
        <h3>{html.escape(s['title'])}</h3>{badge}</div>
      <pre class="detail">{html.escape(s['detail'])}</pre>
      <figure><img src="{src}" alt="{html.escape(s['title'])}">
        <figcaption>لقطة الشاشة {i} — {html.escape(s['file'])}</figcaption></figure>
    </section>""")

    findings = "".join(f"""
  <div class="finding"><h4><span class="dot"></span>{html.escape(t)}</h4>
    <p><strong>المشكلة:</strong> {d}</p><p><strong>الإصلاح:</strong> {s}</p></div>"""
                       for t, d, s in FINDINGS)

    doc = f"""<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>تقرير اختبار التطبيق — المطابق المالي الذكي</title>
<style>
  :root {{ --bg:#020617; --border:#1e2b4d; --text:#e6edf9; --muted:#8ea0bf; --emerald:#10b981; --rose:#f43f5e; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; padding:32px 20px 60px; background:radial-gradient(1100px 600px at 100% -10%, rgba(16,185,129,.10), transparent 60%), var(--bg);
         color:var(--text); font-family:"Tajawal","Segoe UI",Tahoma,sans-serif; line-height:1.85; }}
  .wrap {{ max-width:1080px; margin:0 auto; }}
  header.hero {{ border:1px solid var(--border); border-radius:20px; padding:26px 28px;
                 background:linear-gradient(160deg, rgba(17,29,58,.95), rgba(9,16,34,.95)); box-shadow:0 20px 45px rgba(0,0,0,.45); }}
  .hero .top {{ display:flex; align-items:center; gap:14px; flex-wrap:wrap; }}
  .hero .logo {{ width:52px; height:52px; border-radius:14px; display:grid; place-items:center; font-size:24px; font-weight:800;
                 color:#04120c; background:linear-gradient(135deg,#34d399,#10b981 55%,#059669); }}
  h1 {{ margin:0; font-size:23px; font-weight:800; letter-spacing:-.3px; }}
  .sub {{ color:var(--muted); font-size:13px; }}
  .kpis {{ display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-top:20px; }}
  .kpi {{ border:1px solid var(--border); border-radius:14px; padding:12px 14px; background:rgba(11,20,40,.75); }}
  .kpi span {{ display:block; font-size:11.5px; color:var(--muted); }}
  .kpi strong {{ font-size:19px; }}
  .pass-txt {{ color:var(--emerald); }}
  h2 {{ font-size:18px; margin:34px 0 14px; padding-bottom:8px; border-bottom:1px solid var(--border); }}
  .step {{ border:1px solid var(--border); border-radius:18px; background:linear-gradient(160deg, rgba(17,29,58,.9), rgba(9,16,34,.9));
           padding:18px 20px; margin-bottom:20px; box-shadow:0 16px 34px rgba(0,0,0,.35); }}
  .step-head {{ display:flex; align-items:center; gap:12px; }}
  .num {{ width:30px; height:30px; flex:0 0 30px; border-radius:9px; display:grid; place-items:center; font-weight:800; font-size:14px;
          color:#04120c; background:linear-gradient(135deg,#34d399,#10b981); }}
  .step-head h3 {{ margin:0; font-size:15.5px; font-weight:800; flex:1; }}
  .badge {{ font-size:11.5px; font-weight:800; padding:3px 10px; border-radius:999px; white-space:nowrap; }}
  .badge.pass {{ color:#065f46; background:#a7f3d0; }}
  .badge.fail {{ color:#7f1d1d; background:#fecaca; }}
  pre.detail {{ margin:12px 0 14px; padding:12px 14px; border-radius:12px; background:rgba(2,6,23,.75);
                border:1px solid rgba(30,43,77,.8); color:#b9cbe6; font-family:Consolas,monospace;
                font-size:12.3px; white-space:pre-wrap; direction:rtl; }}
  figure {{ margin:0; }}
  figure img {{ width:100%; border-radius:12px; border:1px solid var(--border); display:block; }}
  figcaption {{ font-size:11.5px; color:var(--muted); margin-top:6px; }}
  .finding {{ border:1px solid var(--border); border-right:3px solid var(--rose); border-radius:14px;
              padding:14px 18px; margin-bottom:14px; background:rgba(11,20,40,.6); }}
  .finding h4 {{ margin:0 0 8px; font-size:14.5px; display:flex; align-items:center; gap:8px; }}
  .dot {{ width:9px; height:9px; border-radius:50%; background:var(--rose); box-shadow:0 0 10px var(--rose); }}
  .finding p {{ margin:4px 0; font-size:13px; color:#c2d3ea; }}
  code {{ background:rgba(2,6,23,.8); padding:1px 6px; border-radius:6px; font-size:12px; color:#7ee7bd; direction:ltr; display:inline-block; }}
  .note {{ border:1px solid rgba(16,185,129,.4); background:rgba(16,185,129,.08); border-radius:14px; padding:14px 18px; font-size:13px; color:#cbe9dd; }}
  footer {{ margin-top:36px; text-align:center; color:#64748b; font-size:12px; }}
</style></head>
<body><div class="wrap">
  <header class="hero">
    <div class="top"><div class="logo">﷼</div>
      <div><h1>تقرير اختبار التطبيق — نظام المطابق المالي الذكي</h1>
      <div class="sub">اختبار آلي للبرنامج الحقيقي (Electron) مع تصوير كل عملية · {datetime.date.today().isoformat()}</div></div></div>
    <div class="kpis">
      <div class="kpi"><span>العمليات المُختبرة</span><strong>{len(steps)}</strong></div>
      <div class="kpi"><span>النتيجة</span><strong class="pass-txt">{passed} / {len(steps)} ناجحة</strong></div>
      <div class="kpi"><span>بيئة الاختبار</span><strong style="font-size:14px">Electron 29 · Windows x64</strong></div>
      <div class="kpi"><span>المُختبَر</span><strong style="font-size:14px">محتوى app.asar المضمّن</strong></div>
    </div>
  </header>
  <h2>الأخطاء المكتشفة أثناء الاختبار (وأُصلحت)</h2>
  {findings}
  <h2>خطوات الاختبار المصوّرة</h2>
  {''.join(blocks)}
  <h2>كيف تعيد الاختبار</h2>
  <div class="note"><code>npm install</code> ثم <code>bash tools/run-ui-test.sh</code> — يشغّل البرنامج وينفّذ العمليات ويحفظ لقطة لكل عملية.
    ملف Excel المستخدم: <code>tools/test-data/كشف-العمقي-يناير.xlsx</code></div>
  <footer>أُعدّ التقرير آلياً بواسطة tools/build-report.py · عدد الصور: {len(steps)} · أخطاء واجهة مسجّلة: {len(console)}</footer>
</div></body></html>"""

    open(OUT, 'w', encoding='utf-8').write(doc)
    print('تم إنشاء:', OUT, '|', os.path.getsize(OUT) // 1024, 'KB |', passed, '/', len(steps), 'ناجحة')


if __name__ == '__main__':
    main()
