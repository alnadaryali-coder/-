/**
 * patch-electron-builder.js
 * ---------------------------------------------------------------------------
 * تعديلات لازمة لبناء مثبّت Windows من لينكس بدون wine32:
 *  1) استخدام rcedit-x64 بدل rcedit-ia32 داخل wine (وضع 64-bit فقط).
 *  2) استخراج برنامج إزالة التثبيت بقارئ PE النقي بدل تشغيل المثبّت تحت wine32.
 * يعمل بأمان عند تكراره (idempotent).
 * ---------------------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..', 'node_modules', 'app-builder-lib', 'out');

function patch(relPath, from, to, label) {
  const file = path.join(root, relPath);
  if (!fs.existsSync(file)) {
    console.log(`[skip] ${relPath} غير موجود`);
    return;
  }
  let src = fs.readFileSync(file, 'utf8');
  if (src.includes(to)) {
    console.log(`[ok] ${label} مطبّق مسبقاً`);
    return;
  }
  if (!src.includes(from)) {
    console.log(`[warn] ${label}: لم يتم العثور على النص الأصلي — تحقق من إصدار electron-builder`);
    return;
  }
  src = src.replace(from, to);
  fs.writeFileSync(file, src);
  console.log(`[done] ${label}`);
}

patch(
  'wine.js',
  'const commandArgs = ["wine", "--ia32", file];',
  'const commandArgs = ["wine", "--ia32", file64 != null ? file64 : file];',
  'rcedit 64-bit'
);

patch(
  path.join('targets', 'nsis', 'NsisTarget.js'),
  `        else {
            await (0, wine_1.execWine)(installerPath, null, [], { env: { __COMPAT_LAYER: "RunAsInvoker" } });
        }`,
  `        else {
            // استخراج برنامج إزالة التثبيت عبر قارئ PE النقي (بدون wine32)
            try {
                await nsisUtil_1.UninstallerReader.exec(installerPath, uninstallerPath);
            }
            catch (error) {
                builder_util_1.log.warn(\`fallback to wine for uninstaller: \${error.message}\`);
                await (0, wine_1.execWine)(installerPath, null, [], { env: { __COMPAT_LAYER: "RunAsInvoker" } });
            }
        }`,
  'NSIS uninstaller without wine32'
);
