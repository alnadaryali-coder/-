/**
 * ui-test-harness.js
 * ---------------------------------------------------------------------------
 * اختبار آلي لواجهة التطبيق مع أخذ صورة (Screenshot) بعد كل عملية.
 * يعمل بتشغيل البرنامج الحقيقي (Electron) ويستخدم نفس ملفات الإنتاج:
 * main.js · preload.js · renderer.js · index.html · style.css
 *
 * التشغيل:  bash tools/run-ui-test.sh
 * الصور:    test-shots/*.png
 * ---------------------------------------------------------------------------
 */
const electron = require('electron');
const { app, BrowserWindow, dialog } = electron;
const fs = require('fs');
const path = require('path');
const os = require('os');

const OUT = process.env.SHOT_DIR || path.join(__dirname, '..', '..', 'test-shots');
const XLSX_FILE = process.env.XLSX_FILE || path.join('/tmp/test-data', 'كشف-العمقي-يناير.xlsx');
const PHASE = process.env.PHASE || 'main';

fs.mkdirSync(OUT, { recursive: true });

// توجيه نافذة اختيار الملف إلى ملف الاختبار بدل نافذة ويندوز
dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [XLSX_FILE] });

require(process.env.APP_MAIN || path.join(__dirname, 'app-main.js'));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const logs = [];
const consoleMsgs = [];

const js = (win, code) => win.webContents.executeJavaScript(code, true);

async function annotate(win, step, title, detail, verdict) {
  const payload = JSON.stringify({ step, title, detail, verdict });
  await js(win, `(() => {
    let o = document.getElementById('testOverlay');
    if (!o) { o = document.createElement('div'); o.id = 'testOverlay'; document.body.appendChild(o); }
    const d = ${payload};
    // إبعاد رسائل التنبيه حتى لا تغطي لوحة الشرح
    const th = document.getElementById('toastHost');
    if (th) { th.style.bottom = '245px'; th.style.left = '16px'; }
    const color = d.verdict === 'fail' ? '#f43f5e' : '#34d399';
    o.style.cssText = 'position:fixed;bottom:16px;left:16px;width:620px;z-index:9998;' +
      'background:rgba(6,13,32,.975);border:1px solid ' + color + ';border-radius:14px;' +
      'padding:12px 16px;color:#e6edf9;font-family:Tajawal,Segoe UI,Tahoma,sans-serif;' +
      'direction:rtl;box-shadow:0 18px 40px rgba(0,0,0,.55);line-height:1.65';
    o.innerHTML =
      '<div style="font-size:11px;font-weight:800;letter-spacing:.4px;color:' + color + ';margin-bottom:3px">' +
        'صورة اختبار ' + d.step + '</div>' +
      '<div style="font-size:14.5px;font-weight:800;margin-bottom:5px">' + d.title + '</div>' +
      '<div style="font-size:12px;color:#a9bcd8;white-space:pre-wrap">' + d.detail + '</div>';
  })()`);
}

async function shot(win, file, step, title, detail, verdict = 'pass') {
  await annotate(win, step, title, detail, verdict);
  await sleep(400);
  const img = await win.webContents.capturePage();
  fs.writeFileSync(path.join(OUT, file), img.toPNG());
  logs.push({ file, step, title, detail, verdict });
  console.log('SHOT', file, '|', title, '|', verdict);
}

async function currentWin() {
  await sleep(300);
  return BrowserWindow.getAllWindows()[0];
}

/* ============================ المرحلة الأولى ============================ */
async function phaseMain() {
  await sleep(2200);
  const win = await currentWin();
  win.webContents.on('console-message', (_e, level, message) => consoleMsgs.push(`${level}: ${message}`));

  // 1) التشغيل والتهيئة
  const accounts = await js(win, 'window.api.getAllAccounts()');
  const cats = await js(win, 'window.api.getAllCategories()');
  const tx0 = await js(win, 'window.api.getAllTransactions()');
  await shot(win, '01-launch.png', 1, 'تشغيل التطبيق وتهيئة قاعدة البيانات',
    `الحسابات الافتراضية: ${accounts.length} · بنود التصنيف: ${cats.length} · الحركات: ${tx0.length}\n` +
    accounts.map((a) => `• ${a.name} — ${Number(a.initialBalance).toLocaleString('en-US')} ${a.currency}`).join('\n'));

  // 2) استيراد كشف Excel
  const xlsxExists = fs.existsSync(XLSX_FILE);
  await js(win, `document.getElementById('btnImportExcel').click(); true`);
  await sleep(2000);
  const tx1 = await js(win, 'window.api.getAllTransactions()');
  const toast1 = await js(win, `(document.getElementById('toastHost')||{}).textContent || ''`);
  const rowsShown = await js(win, `document.querySelectorAll('#recentList li').length`);
  await shot(win, '02-import-excel.png', 2, 'استيراد كشف Excel (6 حركات)',
    `الملف: كشف-العمقي-يناير.xlsx (${xlsxExists ? 'موجود' : 'غير موجود!'})\nرسالة البرنامج: ${toast1}\n` +
    `الحركات في قاعدة البيانات: ${tx1.length} · الصفوف المعروضة في القائمة: ${rowsShown}\n` +
    tx1.slice(0, 3).map((t) => `• ${t.date} · ${t.docNum} · ${t.description} · ${Number(t.credit || t.debit).toLocaleString('en-US')} ر.س ← ${t.categoryName || 'بدون تصنيف'}`).join('\n'),
    tx1.length === 6 ? 'pass' : 'fail');

  // 3) إعادة استيراد نفس الملف (منع التكرار)
  await js(win, `(() => { const t = document.getElementById('toastHost'); if (t) t.innerHTML = '';
    document.getElementById('btnImportExcel').click(); return true; })()`);
  await sleep(2000);
  const tx2 = await js(win, 'window.api.getAllTransactions()');
  const toast2 = await js(win, `(document.getElementById('toastHost')||{}).textContent || ''`);
  await shot(win, '03-duplicate-guard.png', 3, 'إعادة استيراد نفس الملف (فحص منع التكرار)',
    `رسالة البرنامج: ${toast2}\nعدد الحركات قبل: ${tx1.length} — بعد: ${tx2.length}\n` +
    `${tx2.length === tx1.length ? 'لم تُضف أي حركة مكررة ✔' : 'تم إدخال تكرار ✘'}`,
    tx2.length === tx1.length ? 'pass' : 'fail');

  // 4) إضافة حركة مفردة + التصنيف التلقائي
  const newId = await js(win, `window.api.addTransaction({
      date: '2026-01-20', docType: 'سند صرف', docNum: 'MAN-900',
      account: 'صندوق الفرع الرئيسي (كاش)', beneficiary: 'شركة الكهرباء',
      description: 'سداد فاتورة كهرباء الفرع', debit: 3200, credit: 0 })`);
  await js(win, 'location.reload(); true');
  await sleep(2400);
  const win2 = await currentWin();
  const tx3 = await js(win2, 'window.api.getAllTransactions()');
  const added = tx3.find((t) => t._id === newId);
  await shot(win2, '04-add-single.png', 4, 'إضافة حركة مفردة + التصنيف التلقائي',
    `الحركة: ${added ? added.description : 'غير موجودة'} · ${added ? added.docNum : ''} · ${added ? added.debit : 0} ر.س\n` +
    `التصنيف التلقائي بالكلمات المفتاحية: ${added && added.categoryName}\n` +
    `إجمالي الحركات: ${tx3.length} · ظهرت في القائمة العلوية: ${added ? 'نعم' : 'لا'}`,
    added ? 'pass' : 'fail');

  // 5) حذف الحركة
  const delOk = await js(win2, `window.api.deleteTransaction(${JSON.stringify(newId)})`);
  await js(win2, 'location.reload(); true');
  await sleep(2400);
  const win3 = await currentWin();
  const tx4 = await js(win3, 'window.api.getAllTransactions()');
  await shot(win3, '05-delete-single.png', 5, 'حذف الحركة المفردة',
    `نتيجة الحذف: ${delOk ? 'تم بنجاح' : 'فشل'}\nعدد الحركات بعد الحذف: ${tx4.length}\n` +
    `هل بقيت الحركة؟ ${tx4.some((t) => t._id === newId) ? 'نعم ✘' : 'لا ✔'}`,
    delOk && !tx4.some((t) => t._id === newId) ? 'pass' : 'fail');

  // 6) البحث السريع
  await js(win3, `(() => { const i = document.querySelector('.top-actions input[type="text"]');
    i.value = 'عمولة'; i.dispatchEvent(new Event('input')); return true; })()`);
  await sleep(700);
  const filtered = await js(win3, `document.querySelectorAll('#recentList li').length`);
  await shot(win3, '06-search.png', 6, 'البحث السريع (كلمة: عمولة)',
    `عدد الصفوف بعد الفلترة: ${filtered} من ${tx4.length}\nالفلترة تعمل على: رقم المستند · الجهة · البيان · الحساب · التصنيف`,
    filtered > 0 && filtered < tx4.length ? 'pass' : 'fail');

  // 7) المؤشرات المحسوبة
  const cards = await js(win3, `Array.from(document.querySelectorAll('.stat-card h3')).map(e => e.textContent)`);
  await js(win3, `(() => { const i = document.querySelector('.top-actions input[type="text"]');
    i.value = ''; i.dispatchEvent(new Event('input')); return true; })()`);
  await sleep(500);
  await shot(win3, '07-stats.png', 7, 'تحديث المؤشرات المالية من قاعدة البيانات',
    `إجمالي الأرصدة: ${cards[0]}\nالمصروفات التشغيلية: ${cards[1]}\nالعمولات والرسوم البنكية: ${cards[2]}\nإجمالي الإيرادات: ${cards[3]}`,
    'pass');

  // 8) إلغاء الاستيراد (سلوك زر الإلغاء)
  dialog.showOpenDialog = async () => ({ canceled: true, filePaths: [] });
  await js(win3, `(() => { const t = document.getElementById('toastHost'); if (t) t.innerHTML = '';
    document.getElementById('btnImportExcel').click(); return true; })()`);
  await sleep(1200);
  const tx5 = await js(win3, 'window.api.getAllTransactions()');
  const btnLabel = await js(win3, `document.getElementById('btnImportExcel').textContent`);
  await shot(win3, '08-cancel-dialog.png', 8, 'إلغاء نافذة اختيار الملف',
    `عدد الحركات بعد الإلغاء: ${tx5.length} (بلا تغيير)\nحالة الزر: «${btnLabel}» — عاد طبيعياً بعد الإلغاء`,
    tx5.length === tx4.length && btnLabel === 'استيراد كشف Excel' ? 'pass' : 'fail');

  fs.writeFileSync(path.join(OUT, 'logs.json'), JSON.stringify({ logs, consoleMsgs }, null, 2));
  app.quit();
}

/* ============================ المرحلة الثانية ============================ */
/* إعادة تشغيل البرنامج للتأكد من استمرار البيانات بعد الإغلاق */
async function phaseRestart() {
  await sleep(2200);
  const win = await currentWin();
  const tx = await js(win, 'window.api.getAllTransactions()');
  const accounts = await js(win, 'window.api.getAllAccounts()');
  const rowsShown = await js(win, `document.querySelectorAll('#recentList li').length`);
  await shot(win, '09-restart-persistence.png', 9, 'إعادة تشغيل البرنامج (استمرار البيانات)',
    `بعد الإغلاق والتشغيل من جديد:\nالحركات: ${tx.length} · الحسابات: ${accounts.length} · صفوف القائمة: ${rowsShown}\n` +
    `${tx.length === 6 ? 'كل الحركات محفوظة ✔ (٦ حركات مستوردة، والمضافة والمحذوفة كما هي)' : 'عدد غير متوقع ✘'}`,
    tx.length === 6 ? 'pass' : 'fail');

  // دمج سجل هذه المرحلة مع سجل المرحلة الأولى
  const logFile = path.join(OUT, 'logs.json');
  let merged = { logs: [], consoleMsgs: [] };
  if (fs.existsSync(logFile)) {
    try { merged = JSON.parse(fs.readFileSync(logFile, 'utf8')); } catch (_) {}
  }
  merged.logs = (merged.logs || []).concat(logs);
  merged.consoleMsgs = (merged.consoleMsgs || []).concat(consoleMsgs);
  fs.writeFileSync(logFile, JSON.stringify(merged, null, 2));
  app.quit();
}

app.whenReady().then(() => {
  setTimeout(() => {
    (PHASE === 'restart' ? phaseRestart() : phaseMain()).catch((err) => {
      console.error('TEST_FAIL', err && err.stack || err);
      app.quit();
    });
  }, 400);
});
