/* ============================================================
   renderer.js — واجهة التشغيل
   يربط شاشة لوحة التحكم بقاعدة البيانات عبر window.api (preload)
   ============================================================ */

const state = { accounts: [], categories: [], transactions: [] };

document.addEventListener('DOMContentLoaded', async () => {
  wireImportButton();
  wireSearch();
  await refresh();
});

/* ------------------------------ ربط الأزرار ------------------------------ */
function wireImportButton() {
  const btn = document.getElementById('btnImportExcel');
  if (!btn) return;
  btn.addEventListener('click', () => importExcel(btn));
}

function wireSearch() {
  const input = document.querySelector('.top-actions input[type="text"]');
  if (!input) return;
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    const rows = q
      ? state.transactions.filter((t) =>
          [t.docNum, t.beneficiary, t.description, t.account, t.categoryName]
            .join(' ').toLowerCase().includes(q))
      : state.transactions;
    renderRecentMovements(rows);
  });
}

/* ------------------------------ تحميل البيانات ------------------------------ */
async function refresh() {
  if (!window.api) return;
  try {
    const [accounts, categories, transactions] = await Promise.all([
      window.api.getAllAccounts(),
      window.api.getAllCategories(),
      window.api.getAllTransactions()
    ]);
    state.accounts = accounts || [];
    state.categories = categories || [];
    state.transactions = transactions || [];
    renderRecentMovements(state.transactions);
    renderStats();
  } catch (err) {
    showToast('تعذر تحميل البيانات: ' + err.message, 'error');
  }
}

/* ------------------------------ عرض الحركات ------------------------------ */
function renderRecentMovements(txs) {
  const list = document.getElementById('recentList');
  if (!list) return;

  const rows = (txs || [])
    .slice()
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .slice(0, 8);

  if (rows.length === 0) {
    list.innerHTML = `
      <li class="movement-item">
        <span>لا توجد حركات بعد — استخدم «استيراد كشف Excel» أو أضف حركة</span>
        <strong>0 ر.س</strong>
      </li>`;
    return;
  }

  list.innerHTML = rows.map((t) => {
    const isCredit = Number(t.credit) > 0;
    const amount = isCredit ? t.credit : t.debit;
    const label = [t.beneficiary !== 'غير محدد' ? t.beneficiary : '', t.description]
      .filter(Boolean).join(' — ') || t.docType || 'حركة';
    return `
      <li class="movement-item ${isCredit ? 'credit' : 'debit'}">
        <span>${escapeHtml(label)}${t.docNum ? ` <small style="opacity:.6">#${escapeHtml(t.docNum)}</small>` : ''}</span>
        <strong>${formatAmount(amount)} ر.س</strong>
      </li>`;
  }).join('');
}

/* ------------------------------ المؤشرات ------------------------------ */
function renderStats() {
  const cards = document.querySelectorAll('.stat-card h3');
  if (cards.length < 4 || state.transactions.length === 0) return;

  const totalBalances = state.accounts.reduce((s, a) => s + (Number(a.initialBalance) || 0), 0);
  const totalDebit = state.transactions.reduce((s, t) => s + (Number(t.debit) || 0), 0);
  const totalCredit = state.transactions.reduce((s, t) => s + (Number(t.credit) || 0), 0);
  const commission = state.transactions
    .filter((t) => (t.categoryName || '').includes('عمولات') || (t.categoryName || '').includes('رسوم'))
    .reduce((s, t) => s + (Number(t.debit) || 0), 0);

  cards[0].textContent = `${formatAmount(totalBalances)} ر.س`;
  cards[1].textContent = `${formatAmount(totalDebit)} ر.س`;
  cards[2].textContent = `${formatAmount(commission)} ر.س`;
  cards[3].textContent = `${formatAmount(totalCredit)} ر.س`;
}

/* ------------------------------ استيراد Excel ------------------------------ */
async function importExcel(btn) {
  const originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'جارٍ القراءة...';

  try {
    const buffer = await window.api.openExcelFileDialog();
    if (!buffer) return; // ألغى المستخدم

    const rows = parseWorkbook(buffer);
    if (rows.length === 0) {
      showToast('لم يتم العثور على حركات في الملف. تأكد من وجود صفوف بيانات.', 'error');
      return;
    }

    const result = await window.api.importBatch(rows);
    await refresh();
    showToast(
      `تم استيراد ${result.insertedCount} حركة جديدة، وتجاهل ${result.skippedCount} حركة مكررة.`,
      'success'
    );
  } catch (err) {
    showToast('تعذر استيراد الملف: ' + err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = originalLabel;
  }
}

/* تحويل محتوى ملف Excel إلى صفوف يفهمها البرنامج */
function parseWorkbook(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const workbook = XLSX.read(bytes, { type: 'array', cellDates: true });
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) return [];

  const sheet = workbook.Sheets[sheetName];
  const json = XLSX.utils.sheet_to_json(sheet, { defval: '', raw: false });
  return json.map(normalizeRow).filter((r) => r.date || r.debit || r.credit);
}

const HEADER_ALIASES = {
  date: ['التاريخ', 'تاريخ', 'تاريخ العملية', 'تاريخ المستند', 'date'],
  docType: ['نوع المستند', 'نوع الحركة', 'نوع', 'doctype', 'type'],
  docNum: ['رقم المستند', 'رقم السند', 'رقم القيد', 'المستند', 'docnum', 'رقم'],
  account: ['الحساب', 'الصندوق', 'الخزينة', 'account'],
  beneficiary: ['الجهة', 'المستفيد', 'العميل', 'الاسم', 'beneficiary', 'party'],
  description: ['البيان', 'الوصف', 'التفاصيل', 'التوضيح', 'description', 'details'],
  debit: ['مدين', 'المصروف', 'مدين (ر.س)', 'debit', 'out'],
  credit: ['دائن', 'الإيراد', 'الوارد', 'دائن (ر.س)', 'credit', 'in'],
  amount: ['المبلغ', 'القيمة', 'amount', 'value']
};

function normalizeRow(raw) {
  const row = {};
  for (const [target, aliases] of Object.entries(HEADER_ALIASES)) {
    const key = Object.keys(raw).find((k) =>
      aliases.includes(String(k).trim().toLowerCase()) || aliases.includes(String(k).trim())
    );
    row[target] = key !== undefined ? raw[key] : '';
  }

  // إن لم توجد أعمدة مدين/دائن، استخدم عمود المبلغ مع إشارته
  if (!row.debit && !row.credit && row.amount !== '') {
    const value = toNumber(row.amount);
    if (value >= 0) row.credit = value;
    else row.debit = Math.abs(value);
  }

  return {
    date: toDateString(row.date),
    docType: String(row.docType || 'قيد آلي').trim(),
    docNum: String(row.docNum || '').trim(),
    account: String(row.account || 'صندوق المركز').trim(),
    beneficiary: String(row.beneficiary || 'غير محدد').trim(),
    description: String(row.description || '').trim(),
    debit: toNumber(row.debit),
    credit: toNumber(row.credit)
  };
}

function toNumber(value) {
  if (typeof value === 'number') return value;
  if (value === null || value === undefined) return 0;
  const cleaned = String(value).replace(/[^\d.\-]/g, '');
  return parseFloat(cleaned) || 0;
}

function toDateString(value) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === 'number' && value > 20000 && value < 60000) {
    // تاريخ Excel الرقمي
    const d = new Date(Math.round((value - 25569) * 86400 * 1000));
    if (!isNaN(d)) return d.toISOString().slice(0, 10);
  }
  const text = String(value || '').trim().replace(/\//g, '-');
  return text;
}

/* ------------------------------ أدوات مساعدة ------------------------------ */
function formatAmount(value) {
  const n = Number(value) || 0;
  return n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function escapeHtml(text) {
  return String(text == null ? '' : text).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function showToast(message, type = 'success') {
  let host = document.getElementById('toastHost');
  if (!host) {
    host = document.createElement('div');
    host.id = 'toastHost';
    host.style.cssText =
      'position:fixed;bottom:22px;left:22px;display:flex;flex-direction:column;gap:8px;z-index:9999';
    document.body.appendChild(host);
  }

  const toast = document.createElement('div');
  const color = type === 'error' ? '#f43f5e' : '#10b981';
  toast.style.cssText = `padding:12px 16px;border-radius:12px;font-size:13.5px;font-weight:600;
    color:#e9f6ff;background:rgba(9,17,34,.96);border:1px solid ${color};
    box-shadow:0 14px 30px rgba(0,0,0,.45);max-width:420px;line-height:1.6`;
  toast.textContent = message;
  host.appendChild(toast);
  setTimeout(() => toast.remove(), 6000);
}
