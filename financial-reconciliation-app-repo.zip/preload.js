const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getAllTransactions: () => ipcRenderer.invoke('db:get-all'),
  importBatch: (rows) => ipcRenderer.invoke('db:import-batch', rows),
  addTransaction: (row) => ipcRenderer.invoke('db:add-single', row),
  deleteTransaction: (id) => ipcRenderer.invoke('db:delete-single', id),
  openExcelFileDialog: () => ipcRenderer.invoke('dialog:open-excel-file'),
  getAllAccounts: () => ipcRenderer.invoke('accounts:get-all'),
  getAllCategories: () => ipcRenderer.invoke('categories:get-all')
});